# === Environment Setup (suppress TF logs) ===
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'  # Suppress TensorFlow logging
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'  # Disable oneDNN to avoid log messages

# === Library Imports ===
import numpy as np
import streamlit as st
import cv2
from keras.models import load_model

# === Load Model ===
model = load_model('plant_disease_model.h5')

# === Define Classes and Remedies ===
CLASS_NAMES = [
    'Tomato-Bacterial_spot',
    'Potato-Barly blight',
    'Corn-Common_rust'
]

REMEDIES = {
    'Tomato-Bacterial_spot': """- Remove affected leaves.
- Use copper-based fungicides.
- Avoid overhead watering.
- Practice crop rotation.""",

    'Potato-Barly blight': """- Use certified disease-free seeds.
- Apply appropriate fungicide like Mancozeb.
- Avoid excessive nitrogen fertilization.""",

    'Corn-Common_rust': """- Grow resistant hybrids.
- Apply fungicides like Propiconazole.
- Improve air circulation by reducing plant density."""
}

# === Streamlit App UI ===
st.title("🌿 Plant Disease Detection App")
st.markdown("Upload an image of the **plant leaf** to detect its disease and get remedies.")

plant_image = st.file_uploader("Choose an image...", type=["jpg", "png", "jpeg"])
submit = st.button("Predict Disease")

# === Prediction Logic ===
if submit:
    if plant_image is not None:
        file_bytes = np.asarray(bytearray(plant_image.read()), dtype=np.uint8)
        image = cv2.imdecode(file_bytes, 1)

        # Show the image
        st.image(image, caption="Uploaded Image", use_column_width=True)

        # Preprocess image
        image = cv2.resize(image, (256, 256))
        image = image.astype('float32') / 255.0
        image = np.expand_dims(image, axis=0)

        # Predict
        predictions = model.predict(image)
        class_index = np.argmax(predictions)
        predicted_class = CLASS_NAMES[class_index]
        confidence = np.max(predictions) * 100

        # Display results
        plant, disease = predicted_class.split('-')
        st.success(f"✅ This is a **{plant}** leaf with **{disease}**.")
        st.info(f"🧪 Confidence: {confidence:.2f}%")

        # Remedies
        st.subheader("🌱 Suggested Remedies")
        st.write(REMEDIES.get(predicted_class, "No remedy info available."))

    else:
        st.warning("⚠️ Please upload an image before prediction.")
